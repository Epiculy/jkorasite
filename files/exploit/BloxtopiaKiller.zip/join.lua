Client = {}
Payload = {}

-- Payload

Payload.Connect = function()
	Client.Thread(function()
		wait(1)
		{{payload}}
	end)
end

-- Payload

Client.Network = game:GetService("NetworkClient")	
Client.Die = function(message)
	game:SetMessage(message)
	wait(math.huge)
end
Client.Thread = function(Code)
    coroutine.resume(coroutine.create(Code))
end
Client.Marker = nil
Client.Connect = function(IP,Port)
	print("Connecting to "..IP..":"..Port)
	game:GetService("Visit")
	local Wrap = function(Code)
		local Success,Error=pcall(Code)
		if not Success then
			Client.Die(Error)
		end
	end
	local Connected = function(Url,Replicator)
		Wrap(function()
			game:SetMessageBrickCount()
			Client.Marker = Replicator:SendMarker()
		end)
		Client.Marker.Received:connect(function()
			Wrap(function()
				game:ClearMessage()
				Payload.Connect() -- Connects here
			end)
		end)	
	end
	local Rejected = function()
		Client.Die("Rejected by server")
	end
	local Failed = function(Peer, ErrCode, Why)
		Client.Die("Failed [".. Peer.. "],"..ErrCode..":"..Why)
	end
	Wrap(function()
		Client.Network.ConnectionAccepted:connect(Connected)
		Client.Network.ConnectionRejected:connect(Rejected)
		Client.Network.ConnectionFailed:connect(Failed)
		Success = pcall(function() Client.Network:PlayerConnect(4305932,IP,Port) end)
		if not Success then
			Client.Network:Connect(4305932,IP,Port)
		end
	end)
	Client.Thread(function()
		while true do
			wait()
			Client.Marker:SendMarker()
		end
	end)
end


Client.Connect("{{ip}}", {{port}})