local message = Instance.new("Message")
message.Text = "Creating a black hole... please wait"
message.Parent = workspace

recursion = function(child)
            for i,v in pairs(child:GetChildren()) do
                if tostring(v.className) == "Part" or tostring(v.className) == "SpawnLocation" or tostring(v.className) == "TrussPart" then
                    v.Anchored = true
                    local speed = .1
                    local cf = v.CFrame
                    v.Size = v.Size * (1-speed)
                    v.CFrame = CFrame.new(cf.p*(1-speed)) * (cf - cf.p)
                end
                recursion(v)
            end
end

while wait(1) do
    recursion(game.Workspace)
end