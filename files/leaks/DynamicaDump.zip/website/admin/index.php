<?php
session_start();
include("./includes/prestart.php");
?>

<html>
	<head>
	<link rel="stylesheet" type="text/css" href="topbar.css">
	<style>
	</style>
	</head>

	<body bgcolor="#DDDDDD" style="margin: 0px; padding: 0px; font-family: Verdana;">
		<div style="background-color:#EEEEEE; border-right: outset 2px #EEEEEE; width: 15%; height: 100%; padding-left: 5px; padding-top: 5px; float: left;">
			<?php
				include("./includes/sidebar.php");
			?>
		</div>
		<div style="width: 84%; float: right;">
			<center>
				<h1>Welcome, <?php print $_SESSION['user_name'];?></h1>
				Here are some pages that do not have links on the site at the moment:
				<br><br><br>
				<a href="http://24.80.135.159:8080/ide/serverstatus">http://24.80.135.159:8080/ide/serverstatus</a><br>
				<a href="http://24.80.135.159:8080/ide/uploadhat">http://24.80.135.159:8080/ide/uploadhat</a><br>
			</center>
		</div>
	</body>
</html>