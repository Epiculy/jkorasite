<?php
if(isset($_SESSION['id']))
{
	if(file_exists("../mod/" . $_SESSION['id']))
	{
		$_MODERATOR = true;
	}
	else
	{
		header("Location: http://androdome.com/ide/Error.php?id=404");
		die();
	}
}
else
{
	header("Location: http://androdome.com/ide/Error.php?id=404");
	die();
}
