# win32launcher
Rewrote the launcher in win32 and cpp because csharp is the worst

# Non-Disclosure Agreement
By viewing this repository in whole or in part, you agree to the terms listed below:
1. You may not share code from this repository in whole or in part
2. You may not disclose any information as to how this program functions
3. You may not share or disclose any files or any information from files in this repository

By violating these terms, you will be removed from the project and your account will be permanently terminated.