#define WINVER 0x0510  
#define _WIN32_WINNT 0x0510  


#pragma comment(linker,"/manifestdependency:\"" \
    "type='win32' " \
    "name='Microsoft.Windows.Common-Controls' " \
    "version='6.0.0.0' " \
    "processorArchitecture='*' "  \
    "publicKeyToken='6595b64144ccf1df' " \
    "language='*'\"")

#include "windows.h"   
#include "resource.h" 
#include "CommCtrl.h"
#include <stdio.h>
#include <iostream>
#include <winreg.h>
#include <wininet.h>
#include <vector>
#include "unzip.h"
#include "winnls.h"
#include "shobjidl.h"
#include "objbase.h"
#include "objidl.h"
#include "shlguid.h"

#ifndef PBS_MARQUEE
#define PBS_MARQUEE  0x08 
#define PBM_SETMARQUEE WM_USER + 10 
#endif
#define WEB_CANT_CONNECT 1
#define WEB_SUCCESS 0

char dyncode[10] = "dyn008://";
char plycode[6] = "okedi";
char vercode[33] = "01234567890123456789012345678912";



HANDLE thread;





#define BUFSIZE 1024
#define MD5LEN  16

DWORD MD5FHASH(LPCSTR filename, std::string &str)
{
    DWORD dwStatus = 0;
    BOOL bResult = FALSE;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    HANDLE hFile = NULL;
    BYTE rgbFile[BUFSIZE];
    DWORD cbRead = 0;
    BYTE rgbHash[MD5LEN];
    DWORD cbHash = 0;
    CHAR rgbDigits[] = "0123456789abcdef";
    // Logic to check usage goes here.

    hFile = CreateFile(filename,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_FLAG_SEQUENTIAL_SCAN,
        NULL);

    if (INVALID_HANDLE_VALUE == hFile)
    {
        dwStatus = GetLastError(); 
        return dwStatus;
    }

    // Get handle to the crypto provider
    if (!CryptAcquireContext(&hProv,
        NULL,
        NULL,
        PROV_RSA_FULL,
        CRYPT_VERIFYCONTEXT))
    {
        dwStatus = GetLastError();
        CloseHandle(hFile);
        return dwStatus;
    }

    if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash))
    {
        dwStatus = GetLastError();
        CloseHandle(hFile);
        CryptReleaseContext(hProv, 0);
        return dwStatus;
    }

    while (bResult = ReadFile(hFile, rgbFile, BUFSIZE, 
        &cbRead, NULL))
    {
        if (0 == cbRead)
        {
            break;
        }

        if (!CryptHashData(hHash, rgbFile, cbRead, 0))
        {
            dwStatus = GetLastError();
            CryptReleaseContext(hProv, 0);
            CryptDestroyHash(hHash);
            CloseHandle(hFile);
            return dwStatus;
        }
    }

    if (!bResult)
    {
        dwStatus = GetLastError();
        CryptReleaseContext(hProv, 0);
        CryptDestroyHash(hHash);
        CloseHandle(hFile);
        return dwStatus;
    }

    cbHash = MD5LEN;
    if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0))
    {
        for (DWORD i = 0; i < cbHash; i++)
        {
			str += rgbDigits[rgbHash[i] >> 4];
			str += rgbDigits[rgbHash[i] & 0xf];
        }
    }
    else
    {
        dwStatus = GetLastError();
    }

    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);
    CloseHandle(hFile);

    return dwStatus; 
}   












HWND hWndMain = NULL;






bool downloading;

class DownloadStatus : public IBindStatusCallback  
{
private:
public:


	STDMETHOD(OnStartBinding)(
        /* [in] */ DWORD dwReserved,
        /* [in] */ IBinding __RPC_FAR *pib)
        { return E_NOTIMPL; }

    STDMETHOD(GetPriority)(
        /* [out] */ LONG __RPC_FAR *pnPriority)
        { return E_NOTIMPL; }

    STDMETHOD(OnLowResource)(
        /* [in] */ DWORD reserved)
        { return E_NOTIMPL; }

    STDMETHOD(OnProgress)(
        /* [in] */ ULONG ulProgress,
        /* [in] */ ULONG ulProgressMax,
        /* [in] */ ULONG ulStatusCode,
        /* [in] */ LPCWSTR wszStatusText);

    STDMETHOD(OnStopBinding)(
        /* [in] */ HRESULT hresult,
        /* [unique][in] */ LPCWSTR szError)
        { return E_NOTIMPL; }

    STDMETHOD(GetBindInfo)(
        /* [out] */ DWORD __RPC_FAR *grfBINDF,
        /* [unique][out][in] */ BINDINFO __RPC_FAR *pbindinfo)
        { return E_NOTIMPL; }

    STDMETHOD(OnDataAvailable)(
        /* [in] */ DWORD grfBSCF,
        /* [in] */ DWORD dwSize,
        /* [in] */ FORMATETC __RPC_FAR *pformatetc,
        /* [in] */ STGMEDIUM __RPC_FAR *pstgmed)
        { return E_NOTIMPL; }

    STDMETHOD(OnObjectAvailable)(
        /* [in] */ REFIID riid,
        /* [iid_is][in] */ IUnknown __RPC_FAR *punk)
        { return E_NOTIMPL; }

    // IUnknown methods.  Note that IE never calls any of these methods, since
    // the caller owns the IBindStatusCallback interface, so the methods all
    // return zero/E_NOTIMPL.

    STDMETHOD_(ULONG,AddRef)()
        { return 0; }

    STDMETHOD_(ULONG,Release)()
        { return 0; }

    STDMETHOD(QueryInterface)(
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject)
        { return E_NOTIMPL; }
};


HRESULT DownloadStatus::OnProgress ( ULONG ulProgress,   ULONG ulProgressMax, ULONG ulStatusCode, LPCWSTR wszStatusText )
{
		HWND hwndProgressBar = GetDlgItem(hWndMain,IDC_PGB1);
		if(ulProgressMax > 0)
		SendMessageA(hwndProgressBar, PBM_SETPOS, (WPARAM)(((float)ulProgress/(float)ulProgressMax)*1000), 0);
		return S_OK;
}





void setMessage(const char * msg)
{
	SetDlgItemText(hWndMain, IDC_STC1, msg);
	//Sleep(50);
	InvalidateRect(hWndMain, NULL, NULL);
	UpdateWindow(hWndMain);
}

void DoError(const char * msg)
{
	
	HWND bgImg = GetDlgItem(hWndMain,IDC_STATIC3);
	SendMessage(bgImg, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)LoadImage(GetModuleHandle(NULL), (LPCSTR)MAKEINTRESOURCEW(IDB_BITMAP4), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_DEFAULTSIZE));
	setMessage("Failed to start Dynamica");
	HWND hwndProgressBar = GetDlgItem(hWndMain,IDC_PGB1);
    //SendMessageA(hwndProgressBar, PBM_SETMARQUEE, (WPARAM) 0, 0);
	//SetWindowLongA(hwndProgressBar,GWL_STYLE,NULL);

	long style = GetWindowLong(hwndProgressBar,GWL_STYLE);
	SetWindowLongA(hwndProgressBar,GWL_STYLE, style & ~PBS_MARQUEE);

    SendMessageA(hwndProgressBar, PBM_SETMARQUEE, (WPARAM) 0, 0);
	SendMessageA(hwndProgressBar, PBM_SETPOS, (WPARAM) 0, 0);
	EnableWindow(GetDlgItem(hWndMain,DLG1_CANCEL), true);
	SetDlgItemText(hWndMain, IDC_STATIC, msg);
	Sleep(30);
	InvalidateRect(hWndMain, NULL, NULL);
	UpdateWindow(hWndMain);
	TerminateThread(thread, -1);
	//exit(0);
}

std::string MD5(std::string input)
{
    BYTE BytesHash[33];//!
    DWORD dwHashLen = sizeof(BytesHash);
	std::string final;   
    HCRYPTPROV CryptProv;
    HCRYPTHASH CryptHash;
    if (CryptAcquireContext(&CryptProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT | CRYPT_MACHINE_KEYSET)) {
        if (CryptCreateHash(CryptProv, CALG_MD5, 0, 0, &CryptHash))     {
            if (CryptHashData(CryptHash, (BYTE*)input.c_str(), input.length(), 0))          {
                if (CryptGetHashParam(CryptHash, HP_HASHVAL, BytesHash, &dwHashLen, 0))             {
                    final.clear();
					std::string hexcharset = "0123456789abcdef";
                    for (int j = 0; j < 16; j++) {
                        final += hexcharset.substr(((BytesHash[j] >> 4) & 0xF), 1);
                        final += hexcharset.substr(((BytesHash[j]) & 0x0F), 1);
                    }
                }
            }
        }
    }   CryptDestroyHash(CryptHash);
    CryptReleaseContext(CryptProv, 0);
    return final;

}


#include <comdef.h>

HRESULT CreateLink(LPCSTR lpszPathObj, LPCSTR lpszPathLink, LPCSTR lpszDesc, LPCSTR args, int iIcon) 
{ 
    HRESULT hres; 
    IShellLink* psl; 
	CoInitialize(0);
    hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID*)&psl); 
    if (SUCCEEDED(hres)) 
    { 
        IPersistFile* ppf; 
        psl->SetPath(lpszPathObj); 
		if(args != NULL)
			psl->SetArguments(args);
        psl->SetDescription(lpszDesc); 
		if(iIcon != 0)
		{
			psl->SetIconLocation(lpszPathObj, iIcon);
		} 
        hres = psl->QueryInterface(IID_IPersistFile, (LPVOID*)&ppf); 
        if (SUCCEEDED(hres)) 
        { 
            WCHAR wsz[MAX_PATH]; 
            MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1, wsz, MAX_PATH); 
            hres = ppf->Save(wsz, TRUE); 
            ppf->Release(); 
        }	 
		else
		{
			char msg[512] = "QueryInterface failed: ";
			char error[32];
			sprintf(error, "%d", hres);
			strcat(msg, error);
			MessageBox(NULL, msg, "QueryInterface failed", MB_OK);
		}
        psl->Release(); 
    } 
	else
	{
		char msg[512] = "CoCreateInstance failed: ";
		char error[32];
		sprintf(error, "%d", hres);
		strcat(msg, error);
		MessageBox(NULL, msg, "CoCreateInstance", MB_OK);
	}
	if(!SUCCEEDED(hres))
	{
		char msg[512] = "PPF failed to save: ";
		char error[32];
		sprintf(error, "%d", hres);
		strcat(msg, error);
		_com_error err(hres);
		strcat (msg, "\n");
		strcat(msg, err.ErrorMessage());
		strcat (msg, "\n");
		strcat (msg, lpszPathObj);
		strcat (msg, "\n");
		strcat (msg, lpszPathLink);
		MessageBox(NULL, msg, "PPF", MB_OK);
	}
    return hres; 
}




LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
		case WM_CTLCOLORSTATIC:
			{
				HIGHCONTRAST info = { 0 };
				info.cbSize = sizeof(HIGHCONTRAST);
				BOOL ok = SystemParametersInfo(SPI_GETHIGHCONTRAST, 0, &info, 0);

				if(ok && (info.dwFlags & HCF_HIGHCONTRASTON))
				{
					HDC hdcstatic = (HDC)GetDlgItem(hwnd,IDC_STC1);
					SetTextColor(hdcstatic, RGB(0, 51, 153));
					SetBkColor(hdcstatic, RGB(255, 255, 255));
					if ((HDC)lParam == hdcstatic) 
					{
						SetTextColor((HDC)wParam, RGB(0, 51, 153));
					}
					return (INT_PTR)CreateSolidBrush(RGB(255, 255, 255));
				}
				else{
					HDC hdcStatic = (HDC) wParam; 
					if ((HDC)lParam == (HDC)GetDlgItem(hwnd,IDC_STC1)) 
						SetTextColor((HDC)wParam, RGB(0, 51, 153));
					else SetTextColor(hdcStatic, RGB(0, 0, 0));    
					SetBkMode (hdcStatic, TRANSPARENT);
					return (LRESULT)GetStockObject(NULL_BRUSH);
				}
			}
		break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
        break;
        case WM_DESTROY:
            PostQuitMessage(0);
        break;
		case WM_COMMAND:
			switch( HIWORD( wParam ) )
			{
				case BN_CLICKED:
					{
						HWND hdcstatic = GetDlgItem(hwnd,DLG1_CANCEL);
						if((HDC)hdcstatic == (HDC)lParam)
						{
							if(IsWindowEnabled(hdcstatic))
							{
								DestroyWindow(hwnd);
							}
						}
					}
				break;
			}
		break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);

    }
    return 0;
}


BOOL FileExists(const char * szPath)
{
  DWORD dwAttrib = GetFileAttributes((LPCTSTR)szPath);

  return (dwAttrib != INVALID_FILE_ATTRIBUTES && 
         !(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
}

#include <shlobj.h> 

void upgrade(const char * url, char sdir[5])
{
	char msg[128] = "Downloading new ";
	strcat_s(msg, sdir);
	strcat_s(msg, " version...");
	setMessage(msg);
	//InvalidateRect(hWndMain, NULL, NULL);
	
	HWND hwndProgressBar = GetDlgItem(hWndMain,IDC_PGB1);
//  SendMessageA(hwndProgressBar, PBM_SETMARQUEE, (WPARAM) 0, 0);
	long style = GetWindowLong(hwndProgressBar,GWL_STYLE);
	SetWindowLongA(hwndProgressBar,GWL_STYLE, style & ~PBS_MARQUEE);
	SendMessageA(hwndProgressBar, PBM_SETPOS, (WPARAM) 0, 0);
	SendMessage(hwndProgressBar, PBM_SETSTEP, (WPARAM) 1, 0);
	SendMessage(hwndProgressBar, PBM_SETRANGE, 0, MAKELPARAM(0, 1000));
	DownloadStatus * dcif = new DownloadStatus();
	DeleteUrlCacheEntry(url);
	HRESULT hRez = URLDownloadToFile(NULL, url,"C:\\Dynamica\\install.zip", 0, (LPBINDSTATUSCALLBACK)dcif);
	//Sleep(30);
	InvalidateRect(hWndMain, NULL, NULL);
	UpdateWindow(hWndMain);

	char outf[512] = "C:\\Dynamica\\";
	strcat_s(outf, sdir);
	if (CreateDirectory(outf, NULL) ||
    ERROR_ALREADY_EXISTS == GetLastError())
	{
		setMessage("Extracting...");
		if(FileExists("C:\\Dynamica\\install.zip"))
		{
			HZIP hz = OpenZip("C:\\Dynamica\\install.zip",0);
			ZIPENTRY ze; GetZipItem(hz,-1,&ze); int numitems=ze.index;
			HWND text = GetDlgItem(hWndMain,IDC_STC1);
			for (int i=0; i<numitems; i++)
			{ 
			  GetZipItem(hz,i,&ze);
			  char loc[1024] = "C:\\Dynamica\\";
			  strcat_s(loc, sdir);
			  strcat_s(loc, "\\");
			  strcat_s(loc, ze.name);
			  char msg[1024] = "Extracting ";
			  strcat_s(msg, ze.name);
			  strcat_s(msg, "...");
			  SetDlgItemText(hWndMain, IDC_STC1, msg);
			  //Sleep(20);
			  InvalidateRect(hWndMain, NULL, NULL);
			  UpdateWindow(hWndMain);
			  UnzipItem(hz,i,loc);
			  SendMessageA(hwndProgressBar, PBM_SETPOS, (WPARAM)(((float)i/(float)numitems)*1000), 0);
			}
			CloseZip(hz);
			DeleteFile("C:\\Dynamica\\install.zip");
			strcat_s(outf, "\\RobloxApp.exe");
			char startMenuPath[MAX_PATH];
			HRESULT result = SHGetFolderPath(NULL, CSIDL_PROGRAMS, NULL, 0, startMenuPath);
			strcat_s(startMenuPath, "\\Dynamica\\");
			if(!SUCCEEDED(result))
			{
				MessageBox(NULL, "Could not get shortcut path", "", MB_OK);
			}
			else
			{
				if (CreateDirectory(startMenuPath, NULL) || ERROR_ALREADY_EXISTS == GetLastError())
				{
					//Studio
					{
						char loc[MAX_PATH];
						char name[256] = "";

						strcat_s(name, "Dynamica ");
						strcat_s(name, sdir);
						strcat_s(name, " Studio");

						strcpy_s(loc, startMenuPath);
						strcat_s(loc, name);
						strcat_s(loc, ".lnk");

						if(!SUCCEEDED(CreateLink(outf, loc, name, NULL, NULL)))
						{
							char EMSG[512] = "Error in creating shortcut: ";
							strcat_s(EMSG, name);
							MessageBox(NULL, EMSG , "Error", MB_OK);
						}
					}
					//
					//Browser
					{
						char loc[MAX_PATH];
						char name[256] = "";

						strcat_s(name, "Dynamica ");
						strcat_s(name, sdir);
						strcat_s(name, " Player");

						strcpy_s(loc, startMenuPath);
						strcat_s(loc, name);
						strcat_s(loc, ".lnk");

						if(!SUCCEEDED(CreateLink(outf, loc, name, "-Browser", 2)))
						{
							char EMSG[512] = "Error in creating shortcut: ";
							strcat_s(EMSG, name);
							MessageBox(NULL, EMSG , "Error", MB_OK);
						}
					}
				}
				else
				{
					MessageBox(NULL, "Failed to create shortcut path", "Error", MB_OK);
				}
			}
			//
			//Server
			/*{
				char loc[MAX_PATH];
				char name[256] = "";

				strcat_s(name, "Dynamica ");
				strcat_s(name, sdir);
				strcat_s(name, " Server");

				strcpy_s(loc, startMenuPath);
				strcat_s(loc, "\\");
				strcat_s(loc, name);
				strcat_s(loc, ".lnk");

				if(!SUCCEEDED(CreateLink(outf, loc, name, "-no3d", NULL)))
				{
					char EMSG[512] = "Error in creating shortcut:";
					strcat_s(EMSG, name);
					MessageBox(NULL, EMSG , "Error", MB_OK);
				}
			}*/
		}
		else
		{
			setMessage("Failed to download");
			Sleep(1000);
		}
	}
	else
	{
		DoError("Failed to get directory");
	}


	
	style = GetWindowLong(hwndProgressBar,GWL_STYLE);
	SetWindowLongA(hwndProgressBar,GWL_STYLE,style | PBS_MARQUEE);
    SendMessageA(hwndProgressBar, PBM_SETMARQUEE, (WPARAM) 1, 0);

}


bool getInput(char * dyncode, char * plycode, char * vercode, char * command)
{
	for(int i = 0; i < 9; i++)
	{
		if(command[i] == '\0')
		{
			return false;
		}
		dyncode[i] = command[i];
	}
	command += 9;
	for(int i = 0; i < 5; i++)
	{
		if(command[i] == '\0')
			return false;
		plycode[i] = command[i];
	}
	command += 5;
	for(int i = 0; i < 32; i++)
	{
		if(command[i] == '\0')
			return false;
		vercode[i] = command[i];
	}
	return true;
}

int WEB_GET_DATA(char* WEB_URL, char * buffer, int bufferSize)
{
    HINTERNET WEB_CONNECT = InternetOpen("Default_User_Agent", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!WEB_CONNECT)
    {
       return WEB_CANT_CONNECT;
    }

    HINTERNET WEB_ADDRESS = InternetOpenUrl(WEB_CONNECT, WEB_URL, NULL, 0, INTERNET_FLAG_KEEP_CONNECTION | INTERNET_FLAG_PRAGMA_NOCACHE, 0);
    if (!WEB_ADDRESS)
    {
        InternetCloseHandle(WEB_CONNECT);
		return WEB_CANT_CONNECT;
    }
    DWORD NO_BYTES_READ = 0;
	InternetReadFile(WEB_ADDRESS, buffer, bufferSize, &NO_BYTES_READ);

    InternetCloseHandle(WEB_ADDRESS);
    InternetCloseHandle(WEB_CONNECT);
    return WEB_SUCCESS;
}


void checkUpdates(const char * dyncode, bool force = false)
{
	
	std::string str;
	MD5FHASH("C:\\Dynamica\\DLauncher.exe", str); 

	/*
	char launchermd5[512] = "";
	char vurl2[512] = "http://androdome.com/game/version/CurrentVersionLauncher.txt";
	DeleteUrlCacheEntry(vurl2);
	if(WEB_SUCCESS != WEB_GET_DATA(vurl2, launchermd5, 512))
	{
		setMessage("Failed to get most recent launcher");
		Sleep(1000);
		return;
	}
	else if(strlen(launchermd5) != 32)
	{
		setMessage("Failed to get most recent launcher");
		Sleep(1000);
		return;
	}
	else if(strcmp(str.c_str(), launchermd5) != 0)
	{
	}
	*/

	char * ver = "2008";
	if(strcmp(dyncode, "dyn006://") == 0)
		ver = "2006";
	else if(strcmp(dyncode, "dyn007://") == 0)
		ver = "2007";
	else if(strcmp(dyncode, "dyn008://") == 0)
		ver = "2008";
	else if(strcmp(dyncode, "dyn009://") == 0)
		ver = "2009";
	else if(strcmp(dyncode, "dyn010://") == 0)
		ver = "2010";
	else if(strcmp(dyncode, "dyn011://") == 0)
		ver = "2011";
	else if(strcmp(dyncode, "dyn012://") == 0)
		ver = "2012";
	else DoError("Invalid Dyncode");

	char currentmd5[512] = "";
	char vurl[512] = "http://androdome.com/game/version/CurrentVersion";
	strcat_s(vurl, ver);
	strcat_s(vurl, ".txt");
	DeleteUrlCacheEntry(vurl);
	if(WEB_SUCCESS != WEB_GET_DATA(vurl, currentmd5, 512))
	{
		setMessage("Failed to get most recent version");
		Sleep(1000);
		return;
	}
	else if(strlen(currentmd5) != 32)
	{
		setMessage("Failed to get most recent version");
		Sleep(1000);
		return;
	}
	char dir[512] = "C:\\Dynamica\\";
	strcat_s(dir, ver);
	strcat_s(dir, "\\RobloxApp.exe");
	char dir2[512] = "C:\\Dynamica\\";
	strcat_s(dir2, ver);
	strcat_s(dir2, "\\ClientApp.exe");
	if(!FileExists(dir) || !FileExists(dir2)|| force)
	{
		char url[256] = "http://androdome.com/game/version/clients/";
		strcat_s(url, ver);
		strcat_s(url, "/");
		strcat_s(url, currentmd5);
		strcat_s(url, ".zip");
		upgrade(url, ver);
	}
	else
	{
		char dir3[512] = "C:\\Dynamica\\";
		strcat_s(dir3, ver);
		strcat_s(dir3, "\\");
		char file1[512];
		char file2[512];
		char file3[512];
		strcpy_s(file1, dir3);
		strcpy_s(file2, dir3);
		strcpy_s(file3, dir3);
		strcat_s(file1, "RobloxApp.exe");
		strcat_s(file2, "ClientApp.exe");
		strcat_s(file3, "Mlaunch.DLL");

		std::string hash1 = "";
		std::string hash2 = "";
		std::string hash3 = "";
		std::string combHash = "";
		MD5FHASH(file1, hash1);
		MD5FHASH(file2, hash2);
		MD5FHASH(file3, hash3);
		combHash += hash1;
		combHash += hash2;
		combHash += hash3;
		combHash = MD5(combHash);
		if(strcmp(combHash.c_str(), currentmd5) != 0)
		{
			char url[256] = "http://androdome.com/game/version/clients/";
			strcat_s(url, ver);
			strcat_s(url, "/");
			strcat_s(url, currentmd5);
			strcat_s(url, ".zip");
			upgrade(url, ver);
		}
		
	}
}



BOOL Inject(DWORD pID, const char * DLL_NAME) 
{ 
   HANDLE Proc; 
   char buf[50] = {0}; 
   LPVOID RemoteString, LoadLibAddy; 

   if(!pID) 
      return false; 

   Proc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pID); 
   if(!Proc) 
   { 
      sprintf_s(buf, "OpenProcess() failed: %d", GetLastError()); 
      //MessageBox(NULL, buf, "Loader", MB_OK); 
      printf(buf); 
      return false; 
   } 
    
   LoadLibAddy = (LPVOID)GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA"); 

   // Allocate space in the process for our DLL 
   RemoteString = (LPVOID)VirtualAllocEx(Proc, NULL, strlen(DLL_NAME), MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE); 

   // Write the string name of our DLL in the memory allocated 
   WriteProcessMemory(Proc, (LPVOID)RemoteString, DLL_NAME, strlen(DLL_NAME), NULL); 

   // Load our DLL 
   CreateRemoteThread(Proc, NULL, NULL, (LPTHREAD_START_ROUTINE)LoadLibAddy, (LPVOID)RemoteString, NULL, NULL); 

   CloseHandle(Proc); 
   return true; 
}



DWORD WINAPI mainThread(LPVOID lpParameter)
{
	
	if(FileExists("C:\\Dynamica\\SKIP.GET"))
	{
		setMessage("Skipped update check...");
		Sleep(1000);
	}
	else
	{
		checkUpdates(dyncode);
	}
	EnableWindow(GetDlgItem(hWndMain,DLG1_CANCEL), false);
	char fpath[512];
	bool doold = false;
	bool doloadfile = false;
	if(strcmp(dyncode, "dyn006://") == 0)
	{
		doold = true;
		setMessage("Starting Dynamica 2006...");
		strcpy_s(fpath, "C:\\Dynamica\\2006\\");
	}
	else if(strcmp(dyncode, "dyn007://") == 0)
	{
		doold = true;
		setMessage("Starting Dynamica 2007...");
		strcpy_s(fpath, "C:\\Dynamica\\2007\\");
	}
	else if(strcmp(dyncode, "dyn008://") == 0)
	{
		setMessage("Starting Dynamica 2008...");
		strcpy_s(fpath, "C:\\Dynamica\\2008\\");
	}
	else if(strcmp(dyncode, "dyn009://") == 0)	
	{
		setMessage("Starting Dynamica 2009...");
		strcpy_s(fpath, "C:\\Dynamica\\2009\\");
	}
	else if(strcmp(dyncode, "dyn010://") == 0)
	{
		setMessage("Starting Dynamica 2010...");
		strcpy_s(fpath, "C:\\Dynamica\\2010\\");
	}
	else if(strcmp(dyncode, "dyn011://") == 0)
	{
		doloadfile = true;
		setMessage("Starting Dynamica 2011...");
		strcpy_s(fpath, "C:\\Dynamica\\2011\\");
	}
	else if(strcmp(dyncode, "dyn012://") == 0)
	{
		doloadfile = true;
		setMessage("Starting Dynamica 2012...");
		strcpy_s(fpath, "C:\\Dynamica\\2012\\");
	}
	else
	{
		DoError("Dyncode was invalid");
	}
	char dllpath[512];
	strcpy_s(dllpath, fpath);
	strcat_s(dllpath, "MLaunch.dll");
	if(strcmp(plycode, "okply") == 0)
		strcat_s(fpath, "ClientApp.exe");
	else if(strcmp(plycode, "okedi") == 0)
		strcat_s(fpath, "RobloxApp.exe");
	else
		DoError("Plycode was invalid");
	STARTUPINFO info={sizeof(info)};
	PROCESS_INFORMATION processInfo;
	std::string execstr;
	if(!doold && !doloadfile)
	{
		execstr = "  -script \"dofile('http://androdome.com/ide/game/getscript?hvmod=";
		execstr += MD5(vercode);
		execstr += "')\"";
	}
	else if(doold)
	{
		execstr = "  -script \"http://androdome.com/ide/game/getscript?hvmod=";
		execstr += MD5(vercode);
		execstr += "\"";
	}
	else if(doloadfile)
	{
		execstr = "  -script \"loadfile('http://androdome.com/ide/game/getscript?hvmod=";
		execstr += MD5(vercode);
		execstr += "')\"";
	}

	if(CreateProcess(fpath,(LPSTR)execstr.c_str(), NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo))
	{
		Inject(processInfo.dwProcessId, dllpath);
		//WaitForSingleObject(processInfo.hProcess, INFINITE);
		Sleep(4000);
		exit(0);
	}
	else
	{
		const DWORD dwError = GetLastError();  // <<<< immediately saves GetLastError() so we don't lose its value
		char err[512];  // temp buffer to hold our message string (although it would be better to just inspect dwError in the debugger here)
		sprintf_s(err, "Failed to create process. Error code: %u", dwError);
		DoError(err);
	}
 return 0;
}

std::vector<std::string> split(const std::string& s, char seperator)
{
   std::vector<std::string> output;

    std::string::size_type prev_pos = 0, pos = 0;

    while((pos = s.find(seperator, pos)) != std::string::npos)
    {
        std::string substring( s.substr(prev_pos, pos-prev_pos) );

        output.push_back(substring);

        prev_pos = ++pos;
    }

    output.push_back(s.substr(prev_pos, pos-prev_pos)); // Last word

    return output;
}

std::vector<std::string> cmd;

DWORD WINAPI installThread(LPVOID lpParameter)
{
	for(size_t i = 1; i < cmd.size(); i++)
	{
		checkUpdates(cmd[i].c_str(), true);
	}
	EnableWindow(GetDlgItem(hWndMain,DLG1_CANCEL), true);
	SetDlgItemText(hWndMain, DLG1_CANCEL, "Ok");
	HWND hwndProgressBar = GetDlgItem(hWndMain,IDC_PGB1);
	long style = GetWindowLong(hwndProgressBar,GWL_STYLE);
	SetWindowLongA(hwndProgressBar,GWL_STYLE, style & ~PBS_MARQUEE);
	SendMessageA(hwndProgressBar, PBM_SETPOS, (WPARAM) 1000, 0);
	setMessage("Finished installing!");
	exit(0);
	return 0;
}



bool getInstallRequested(LPSTR cmdLine)
{
	
	char code[9] = "12345678";
	for(int i = 0; i < 8; i++)
	{
		if(cmdLine[i] == '\0')
			return false;
		code[i] = cmdLine[i];
	}
	if(strcmp(code, "-install") == 0)
	{
		cmd = split(cmdLine, ' ');
		thread = CreateThread(NULL, 0, installThread, &cmd , 0, 0);
		return true;
	}
	return false;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pCmdLine, int nCmdShow)
{
	InitCommonControls();
	hWndMain = CreateDialogA(NULL, MAKEINTRESOURCEA(IDD_DLG1), NULL, NULL); 
    SetWindowLong(hWndMain,GWL_WNDPROC,(LONG)WndProc);

	
	if(hWndMain != NULL)
	{
		ShowWindow(hWndMain, SW_SHOW);
	}
	else
	{
		const DWORD dwError = GetLastError();  // <<<< immediately saves GetLastError() so we don't lose its value
		char temp[256];  // temp buffer to hold our message string (although it would be better to just inspect dwError in the debugger here)
		sprintf_s(temp, "CreateDialog returned NULL: GetLastError=%u", dwError);  // <<< build temporary message string
		MessageBox(NULL, temp, "Warning!", MB_OK | MB_ICONEXCLAMATION);
	}

	

	HWND hdcstatic = GetDlgItem(hWndMain,IDC_STC1);
	
	HFONT hFont = CreateFont(20, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");
    SendMessage(hdcstatic, WM_SETFONT, WPARAM (hFont), TRUE);

	HBITMAP hBMP = (HBITMAP) LoadImageA( NULL, MAKEINTRESOURCEA(IDB_BITMAP2), IMAGE_BITMAP, 0, 0, NULL);
	
	
	SendMessage(hWndMain, WM_SETICON, ICON_BIG,(LPARAM)LoadImage(hInstance, (LPCSTR)MAKEINTRESOURCEW(IDI_ICON2), IMAGE_ICON, 0, 0, LR_DEFAULTCOLOR | LR_DEFAULTSIZE));
	
	HWND hwndProgressBar = GetDlgItem(hWndMain,IDC_PGB1);

	long style = GetWindowLong(hwndProgressBar,GWL_STYLE);
	SetWindowLongA(hwndProgressBar,GWL_STYLE,style | PBS_MARQUEE);
    SendMessageA(hwndProgressBar, PBM_SETMARQUEE, (WPARAM) 1, 0);

	
	HWND bgImg = GetDlgItem(hWndMain,IDC_STATIC3);
	SendMessage(bgImg, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)LoadImage(hInstance, (LPCSTR)MAKEINTRESOURCEW(IDB_BITMAP2), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_DEFAULTSIZE));
	

	HWND icImg = GetDlgItem(hWndMain,IDC_STATIC4);
	
	SendMessage(icImg, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)LoadImage(hInstance, (LPCSTR)MAKEINTRESOURCEW(IDB_BITMAP3), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_DEFAULTSIZE));

	MSG messages;
	SetForegroundWindow(hWndMain);
	SetFocus(hWndMain);
	SetActiveWindow(hWndMain);
	//SetWindowTheme(hWndMain, L"Explorer", NULL);


	
		if(!getInstallRequested(pCmdLine))
		{
			DeleteFile("C:\\Dynamica\\DLauncherUpdate.exe");
			if(getInput(dyncode, plycode, vercode, (char *)pCmdLine))
				thread = CreateThread(NULL, 0, mainThread, NULL , 0, 0);
			else
				DoError("Invalid Parameters");
		}

	while (GetMessage (&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages);
        DispatchMessage(&messages);
    }
	return 0;
}
