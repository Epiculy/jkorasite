﻿using System;
using System.Windows.Forms;

namespace BloxtopiaUpdater
{
	// Token: 0x02000003 RID: 3
	internal static class Program
	{
		// Token: 0x0600000D RID: 13 RVA: 0x000040A9 File Offset: 0x000022A9
		[STAThread]
		private static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1(args));
		}
	}
}
