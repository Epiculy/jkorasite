﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using BloxtopiaUpdater.Properties;

namespace BloxtopiaUpdater
{
	// Token: 0x02000002 RID: 2
	public partial class Form1 : Form
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public Form1(string[] args)
		{
			this.InitializeComponent();
			bool flag = File.Exists("C:\\Bloxtopia\\BloxtopiaLauncher.exe.old");
			if (flag)
			{
				File.Delete("C:\\Bloxtopia\\BloxtopiaLauncher.exe.old");
			}
			string text = "bloxtopia://";
			bool flag2 = !Directory.Exists("C:\\Bloxtopia");
			if (flag2)
			{
				this.DownloadAndInstall("2008");
			}
			bool flag3 = args.Length == 0 || !args[0].Contains(text);
			if (flag3)
			{
				MessageBox.Show("Please use the site to join games.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				base.Close();
			}
			string text2 = args[0].Replace(text, "").Replace("/", "");
			string text3 = text2.Substring(text2.Length - 4);
			string text4 = text2.Substring(0, text2.Length - 4);
			bool flag4 = text3 == "2008";
			if (flag4)
			{
				string text5 = "C:\\Bloxtopia\\2008";
				bool flag5 = !Directory.Exists(text5);
				if (flag5)
				{
					DialogResult dialogResult = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
					bool flag6 = dialogResult == DialogResult.Yes;
					if (flag6)
					{
						MessageBox.Show("Bloxtopia 2008 will now be installed.");
						this.DownloadAndInstall("2008");
					}
					else
					{
						bool flag7 = dialogResult == DialogResult.No;
						if (flag7)
						{
							base.Close();
						}
					}
				}
				else
				{
					bool flag8 = !File.Exists(text5 + "\\btversion");
					if (flag8)
					{
						this.DownloadAndInstall("2008");
					}
					else
					{
						string a = File.ReadAllText(text5 + "\\btversion");
						WebClient webClient = new WebClient();
						string b = webClient.DownloadString("http://bloxtopia.xyz/clients/btversion_2008");
						bool flag9 = a != b;
						if (flag9)
						{
							this.DownloadAndInstall("2008");
						}
						else
						{
							ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_processor");
							ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
							string str = "";
							foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
							{
								ManagementObject managementObject = (ManagementObject)managementBaseObject;
								str = managementObject["ProcessorID"].ToString();
							}
							Task<string> stringAsync = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str);
							HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str);
							HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
							string text6 = new StreamReader(httpWebResponse.GetResponseStream()).ReadToEnd();
							bool flag10 = text6.ToString() != "false";
							if (flag10)
							{
								bool flag11 = text6.ToString() == "err";
								if (flag11)
								{
									MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
									base.Close();
								}
								else
								{
									MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
									base.Close();
								}
							}
							Process.Start("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\"");
							base.Close();
						}
					}
				}
			}
			else
			{
				bool flag12 = text3 == "2010";
				if (flag12)
				{
					string text7 = "C:\\Bloxtopia\\2010";
					bool flag13 = !Directory.Exists(text7);
					if (flag13)
					{
						DialogResult dialogResult2 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
						bool flag14 = dialogResult2 == DialogResult.Yes;
						if (flag14)
						{
							MessageBox.Show("Bloxtopia 2010 will now be installed.");
							this.DownloadAndInstall("2010");
						}
						else
						{
							bool flag15 = dialogResult2 == DialogResult.No;
							if (flag15)
							{
								base.Close();
							}
						}
					}
					else
					{
						bool flag16 = !File.Exists(text7 + "\\btversion");
						if (flag16)
						{
							this.DownloadAndInstall("2010");
						}
						else
						{
							string a2 = File.ReadAllText(text7 + "\\btversion");
							WebClient webClient2 = new WebClient();
							string b2 = webClient2.DownloadString("http://bloxtopia.xyz/clients/btversion_2010");
							bool flag17 = a2 != b2;
							if (flag17)
							{
								this.DownloadAndInstall("2010");
							}
							else
							{
								ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("Select * From Win32_processor");
								ManagementObjectCollection managementObjectCollection2 = managementObjectSearcher2.Get();
								string str2 = "";
								foreach (ManagementBaseObject managementBaseObject2 in managementObjectCollection2)
								{
									ManagementObject managementObject2 = (ManagementObject)managementBaseObject2;
									str2 = managementObject2["ProcessorID"].ToString();
								}
								Task<string> stringAsync2 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str2);
								HttpWebRequest httpWebRequest2 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str2);
								HttpWebResponse httpWebResponse2 = (HttpWebResponse)httpWebRequest2.GetResponse();
								string text8 = new StreamReader(httpWebResponse2.GetResponseStream()).ReadToEnd();
								bool flag18 = text8.ToString() != "false";
								if (flag18)
								{
									bool flag19 = text8.ToString() == "err";
									if (flag19)
									{
										MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
										base.Close();
									}
									else
									{
										MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
										base.Close();
									}
								}
								ProcessStartInfo[] infos = new ProcessStartInfo[]
								{
									new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
									new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
								};
								Process[] array = this.StartProcesses(infos, false);
							}
						}
					}
				}
				else
				{
					bool flag20 = text3 == "2011";
					if (flag20)
					{
						string text9 = "C:\\Bloxtopia\\2011";
						bool flag21 = !Directory.Exists(text9);
						if (flag21)
						{
							DialogResult dialogResult3 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
							bool flag22 = dialogResult3 == DialogResult.Yes;
							if (flag22)
							{
								MessageBox.Show("Bloxtopia 2011 will now be installed.");
								this.DownloadAndInstall("2011");
							}
							else
							{
								bool flag23 = dialogResult3 == DialogResult.No;
								if (flag23)
								{
									base.Close();
								}
							}
						}
						else
						{
							bool flag24 = !File.Exists(text9 + "\\btversion");
							if (flag24)
							{
								this.DownloadAndInstall("2011");
							}
							else
							{
								string a3 = File.ReadAllText(text9 + "\\btversion");
								WebClient webClient3 = new WebClient();
								string b3 = webClient3.DownloadString("http://bloxtopia.xyz/clients/btversion_2011");
								bool flag25 = a3 != b3;
								if (flag25)
								{
									this.DownloadAndInstall("2011");
								}
								else
								{
									ManagementObjectSearcher managementObjectSearcher3 = new ManagementObjectSearcher("Select * From Win32_processor");
									ManagementObjectCollection managementObjectCollection3 = managementObjectSearcher3.Get();
									string str3 = "";
									foreach (ManagementBaseObject managementBaseObject3 in managementObjectCollection3)
									{
										ManagementObject managementObject3 = (ManagementObject)managementBaseObject3;
										str3 = managementObject3["ProcessorID"].ToString();
									}
									Task<string> stringAsync3 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str3);
									HttpWebRequest httpWebRequest3 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str3);
									HttpWebResponse httpWebResponse3 = (HttpWebResponse)httpWebRequest3.GetResponse();
									string text10 = new StreamReader(httpWebResponse3.GetResponseStream()).ReadToEnd();
									bool flag26 = text10.ToString() != "false";
									if (flag26)
									{
										bool flag27 = text10.ToString() == "err";
										if (flag27)
										{
											MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
											base.Close();
										}
										else
										{
											MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
											base.Close();
										}
									}
									ProcessStartInfo[] infos2 = new ProcessStartInfo[]
									{
										new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
										new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
									};
									Process[] array2 = this.StartProcesses(infos2, false);
								}
							}
						}
					}
					else
					{
						bool flag28 = text3 == "2009";
						if (flag28)
						{
							string text11 = "C:\\Bloxtopia\\2009";
							bool flag29 = !Directory.Exists(text11);
							if (flag29)
							{
								DialogResult dialogResult4 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
								bool flag30 = dialogResult4 == DialogResult.Yes;
								if (flag30)
								{
									MessageBox.Show("Bloxtopia 2009 will now be installed.");
									this.DownloadAndInstall("2009");
								}
								else
								{
									bool flag31 = dialogResult4 == DialogResult.No;
									if (flag31)
									{
										base.Close();
									}
								}
							}
							else
							{
								bool flag32 = !File.Exists(text11 + "\\btversion");
								if (flag32)
								{
									this.DownloadAndInstall("2009");
								}
								else
								{
									string a4 = File.ReadAllText(text11 + "\\btversion");
									WebClient webClient4 = new WebClient();
									string b4 = webClient4.DownloadString("http://bloxtopia.xyz/clients/btversion_2009");
									bool flag33 = a4 != b4;
									if (flag33)
									{
										this.DownloadAndInstall("2009");
									}
									else
									{
										ManagementObjectSearcher managementObjectSearcher4 = new ManagementObjectSearcher("Select * From Win32_processor");
										ManagementObjectCollection managementObjectCollection4 = managementObjectSearcher4.Get();
										string str4 = "";
										foreach (ManagementBaseObject managementBaseObject4 in managementObjectCollection4)
										{
											ManagementObject managementObject4 = (ManagementObject)managementBaseObject4;
											str4 = managementObject4["ProcessorID"].ToString();
										}
										Task<string> stringAsync4 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str4);
										HttpWebRequest httpWebRequest4 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str4);
										HttpWebResponse httpWebResponse4 = (HttpWebResponse)httpWebRequest4.GetResponse();
										string text12 = new StreamReader(httpWebResponse4.GetResponseStream()).ReadToEnd();
										bool flag34 = text12.ToString() != "false";
										if (flag34)
										{
											bool flag35 = text12.ToString() == "err";
											if (flag35)
											{
												MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
												base.Close();
											}
											else
											{
												MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
												base.Close();
											}
										}
										ProcessStartInfo[] infos3 = new ProcessStartInfo[]
										{
											new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
											new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
										};
										Process[] array3 = this.StartProcesses(infos3, false);
									}
								}
							}
						}
						else
						{
							bool flag36 = text3 == "2012";
							if (flag36)
							{
								string text13 = "C:\\Bloxtopia\\2012";
								bool flag37 = !Directory.Exists(text13);
								if (flag37)
								{
									DialogResult dialogResult5 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
									bool flag38 = dialogResult5 == DialogResult.Yes;
									if (flag38)
									{
										MessageBox.Show("Bloxtopia 2012 will now be installed.");
										this.DownloadAndInstall("2012");
									}
									else
									{
										bool flag39 = dialogResult5 == DialogResult.No;
										if (flag39)
										{
											base.Close();
										}
									}
								}
								else
								{
									bool flag40 = !File.Exists(text13 + "\\btversion");
									if (flag40)
									{
										this.DownloadAndInstall("2012");
									}
									else
									{
										string a5 = File.ReadAllText(text13 + "\\btversion");
										WebClient webClient5 = new WebClient();
										string b5 = webClient5.DownloadString("http://bloxtopia.xyz/clients/btversion_2012");
										bool flag41 = a5 != b5;
										if (flag41)
										{
											this.DownloadAndInstall("2012");
										}
										else
										{
											ManagementObjectSearcher managementObjectSearcher5 = new ManagementObjectSearcher("Select * From Win32_processor");
											ManagementObjectCollection managementObjectCollection5 = managementObjectSearcher5.Get();
											string str5 = "";
											foreach (ManagementBaseObject managementBaseObject5 in managementObjectCollection5)
											{
												ManagementObject managementObject5 = (ManagementObject)managementBaseObject5;
												str5 = managementObject5["ProcessorID"].ToString();
											}
											Task<string> stringAsync5 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str5);
											HttpWebRequest httpWebRequest5 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str5);
											HttpWebResponse httpWebResponse5 = (HttpWebResponse)httpWebRequest5.GetResponse();
											string text14 = new StreamReader(httpWebResponse5.GetResponseStream()).ReadToEnd();
											bool flag42 = text14.ToString() != "false";
											if (flag42)
											{
												bool flag43 = text14.ToString() == "err";
												if (flag43)
												{
													MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
													base.Close();
												}
												else
												{
													MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
													base.Close();
												}
											}
											ProcessStartInfo[] infos4 = new ProcessStartInfo[]
											{
												new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-joinscripturl \"http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "\""),
												new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
											};
											Process[] array4 = this.StartProcesses(infos4, false);
										}
									}
								}
							}
							else
							{
								bool flag44 = text3 == "2014";
								if (flag44)
								{
									string text15 = "C:\\Bloxtopia\\2014";
									bool flag45 = !Directory.Exists(text15);
									if (flag45)
									{
										DialogResult dialogResult6 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
										bool flag46 = dialogResult6 == DialogResult.Yes;
										if (flag46)
										{
											MessageBox.Show("Bloxtopia 2014 will now be installed.");
											this.DownloadAndInstall("2014");
										}
										else
										{
											bool flag47 = dialogResult6 == DialogResult.No;
											if (flag47)
											{
												base.Close();
											}
										}
									}
									else
									{
										bool flag48 = !File.Exists(text15 + "\\btversion");
										if (flag48)
										{
											this.DownloadAndInstall("2014");
										}
										else
										{
											string a6 = File.ReadAllText(text15 + "\\btversion");
											WebClient webClient6 = new WebClient();
											string b6 = webClient6.DownloadString("http://bloxtopia.xyz/clients/btversion_2014");
											bool flag49 = a6 != b6;
											if (flag49)
											{
												this.DownloadAndInstall("2014");
											}
											else
											{
												ManagementObjectSearcher managementObjectSearcher6 = new ManagementObjectSearcher("Select * From Win32_processor");
												ManagementObjectCollection managementObjectCollection6 = managementObjectSearcher6.Get();
												string str6 = "";
												foreach (ManagementBaseObject managementBaseObject6 in managementObjectCollection6)
												{
													ManagementObject managementObject6 = (ManagementObject)managementBaseObject6;
													str6 = managementObject6["ProcessorID"].ToString();
												}
												Task<string> stringAsync6 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str6);
												HttpWebRequest httpWebRequest6 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str6);
												HttpWebResponse httpWebResponse6 = (HttpWebResponse)httpWebRequest6.GetResponse();
												string text16 = new StreamReader(httpWebResponse6.GetResponseStream()).ReadToEnd();
												bool flag50 = text16.ToString() != "false";
												if (flag50)
												{
													bool flag51 = text16.ToString() == "err";
													if (flag51)
													{
														MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
														base.Close();
													}
													else
													{
														MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
														base.Close();
													}
												}
												ProcessStartInfo[] infos5 = new ProcessStartInfo[]
												{
													new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-joinscripturl \"http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "\""),
													new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
												};
												Process[] array5 = this.StartProcesses(infos5, false);
											}
										}
									}
								}
								else
								{
									bool flag52 = text3 == "2013";
									if (flag52)
									{
										string text17 = "C:\\Bloxtopia\\2013";
										bool flag53 = !Directory.Exists(text17);
										if (flag53)
										{
											DialogResult dialogResult7 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
											bool flag54 = dialogResult7 == DialogResult.Yes;
											if (flag54)
											{
												MessageBox.Show("Bloxtopia 2013 will now be installed.");
												this.DownloadAndInstall("2013");
											}
											else
											{
												bool flag55 = dialogResult7 == DialogResult.No;
												if (flag55)
												{
													base.Close();
												}
											}
										}
										else
										{
											bool flag56 = !File.Exists(text17 + "\\btversion");
											if (flag56)
											{
												this.DownloadAndInstall("2013");
											}
											else
											{
												string a7 = File.ReadAllText(text17 + "\\btversion");
												WebClient webClient7 = new WebClient();
												string b7 = webClient7.DownloadString("http://bloxtopia.xyz/clients/btversion_2013");
												bool flag57 = a7 != b7;
												if (flag57)
												{
													this.DownloadAndInstall("2013");
												}
												else
												{
													ManagementObjectSearcher managementObjectSearcher7 = new ManagementObjectSearcher("Select * From Win32_processor");
													ManagementObjectCollection managementObjectCollection7 = managementObjectSearcher7.Get();
													string str7 = "";
													foreach (ManagementBaseObject managementBaseObject7 in managementObjectCollection7)
													{
														ManagementObject managementObject7 = (ManagementObject)managementBaseObject7;
														str7 = managementObject7["ProcessorID"].ToString();
													}
													Task<string> stringAsync7 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str7);
													HttpWebRequest httpWebRequest7 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str7);
													HttpWebResponse httpWebResponse7 = (HttpWebResponse)httpWebRequest7.GetResponse();
													string text18 = new StreamReader(httpWebResponse7.GetResponseStream()).ReadToEnd();
													bool flag58 = text18.ToString() != "false";
													if (flag58)
													{
														bool flag59 = text18.ToString() == "err";
														if (flag59)
														{
															MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
															base.Close();
														}
														else
														{
															MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
															base.Close();
														}
													}
													ProcessStartInfo[] infos6 = new ProcessStartInfo[]
													{
														new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-joinscripturl \"http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "\""),
														new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
													};
													Process[] array6 = this.StartProcesses(infos6, false);
												}
											}
										}
									}
									else
									{
										bool flag60 = text3 == "2007";
										if (flag60)
										{
											string text19 = "C:\\Bloxtopia\\2007";
											bool flag61 = !Directory.Exists(text19);
											if (flag61)
											{
												DialogResult dialogResult8 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
												bool flag62 = dialogResult8 == DialogResult.Yes;
												if (flag62)
												{
													MessageBox.Show("Bloxtopia 2007 will now be installed.");
													this.DownloadAndInstall("2007");
												}
												else
												{
													bool flag63 = dialogResult8 == DialogResult.No;
													if (flag63)
													{
														base.Close();
													}
												}
											}
											else
											{
												bool flag64 = !File.Exists(text19 + "\\btversion");
												if (flag64)
												{
													this.DownloadAndInstall("2007");
												}
												else
												{
													string a8 = File.ReadAllText(text19 + "\\btversion");
													WebClient webClient8 = new WebClient();
													string b8 = webClient8.DownloadString("http://bloxtopia.xyz/clients/btversion_2007");
													bool flag65 = a8 != b8;
													if (flag65)
													{
														this.DownloadAndInstall("2007");
													}
													else
													{
														ManagementObjectSearcher managementObjectSearcher8 = new ManagementObjectSearcher("Select * From Win32_processor");
														ManagementObjectCollection managementObjectCollection8 = managementObjectSearcher8.Get();
														string str8 = "";
														foreach (ManagementBaseObject managementBaseObject8 in managementObjectCollection8)
														{
															ManagementObject managementObject8 = (ManagementObject)managementBaseObject8;
															str8 = managementObject8["ProcessorID"].ToString();
														}
														Task<string> stringAsync8 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str8);
														HttpWebRequest httpWebRequest8 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str8);
														HttpWebResponse httpWebResponse8 = (HttpWebResponse)httpWebRequest8.GetResponse();
														string text20 = new StreamReader(httpWebResponse8.GetResponseStream()).ReadToEnd();
														bool flag66 = text20.ToString() != "false";
														if (flag66)
														{
															bool flag67 = text20.ToString() == "err";
															if (flag67)
															{
																MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																base.Close();
															}
															else
															{
																MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																base.Close();
															}
														}
														ProcessStartInfo[] infos7 = new ProcessStartInfo[]
														{
															new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
															new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
														};
														Process[] array7 = this.StartProcesses(infos7, false);
													}
												}
											}
										}
										else
										{
											bool flag68 = text3 == "2006";
											if (flag68)
											{
												string text21 = "C:\\Bloxtopia\\2006";
												bool flag69 = !Directory.Exists(text21);
												if (flag69)
												{
													DialogResult dialogResult9 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
													bool flag70 = dialogResult9 == DialogResult.Yes;
													if (flag70)
													{
														MessageBox.Show("Bloxtopia 2006 will now be installed.");
														this.DownloadAndInstall("2006");
													}
													else
													{
														bool flag71 = dialogResult9 == DialogResult.No;
														if (flag71)
														{
															base.Close();
														}
													}
												}
												else
												{
													bool flag72 = !File.Exists(text21 + "\\btversion");
													if (flag72)
													{
														this.DownloadAndInstall("2006");
													}
													else
													{
														string a9 = File.ReadAllText(text21 + "\\btversion");
														WebClient webClient9 = new WebClient();
														string b9 = webClient9.DownloadString("http://bloxtopia.xyz/clients/btversion_2006");
														bool flag73 = a9 != b9;
														if (flag73)
														{
															this.DownloadAndInstall("2006");
														}
														else
														{
															ManagementObjectSearcher managementObjectSearcher9 = new ManagementObjectSearcher("Select * From Win32_processor");
															ManagementObjectCollection managementObjectCollection9 = managementObjectSearcher9.Get();
															string str9 = "";
															foreach (ManagementBaseObject managementBaseObject9 in managementObjectCollection9)
															{
																ManagementObject managementObject9 = (ManagementObject)managementBaseObject9;
																str9 = managementObject9["ProcessorID"].ToString();
															}
															Task<string> stringAsync9 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str9);
															HttpWebRequest httpWebRequest9 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str9);
															HttpWebResponse httpWebResponse9 = (HttpWebResponse)httpWebRequest9.GetResponse();
															string text22 = new StreamReader(httpWebResponse9.GetResponseStream()).ReadToEnd();
															bool flag74 = text22.ToString() != "false";
															if (flag74)
															{
																bool flag75 = text22.ToString() == "err";
																if (flag75)
																{
																	MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																	base.Close();
																}
																else
																{
																	MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																	base.Close();
																}
															}
															ProcessStartInfo[] infos8 = new ProcessStartInfo[]
															{
																new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
																new ProcessStartInfo("C:\\Bloxtopia\\Bloxtopia AntiCheat.exe", text4)
															};
															Process[] array8 = this.StartProcesses(infos8, false);
														}
													}
												}
											}
											else
											{
												string text23 = "C:\\Bloxtopia\\2010";
												bool flag76 = !Directory.Exists(text23);
												if (flag76)
												{
													DialogResult dialogResult10 = MessageBox.Show("Bloxtopia is not installed. Do you wish to install Bloxtopia?", "Bloxtopia Updater", MessageBoxButtons.YesNo);
													bool flag77 = dialogResult10 == DialogResult.Yes;
													if (flag77)
													{
														MessageBox.Show("Bloxtopia 2010 will now be installed.");
														this.DownloadAndInstall("2010");
													}
													else
													{
														bool flag78 = dialogResult10 == DialogResult.No;
														if (flag78)
														{
															base.Close();
														}
													}
												}
												else
												{
													bool flag79 = !File.Exists(text23 + "\\btversion");
													if (flag79)
													{
														this.DownloadAndInstall("2010");
													}
													else
													{
														string a10 = File.ReadAllText(text23 + "\\btversion");
														WebClient webClient10 = new WebClient();
														string b10 = webClient10.DownloadString("http://bloxtopia.xyz/clients/btversion_2010");
														bool flag80 = a10 != b10;
														if (flag80)
														{
															this.DownloadAndInstall("2010");
														}
														else
														{
															ManagementObjectSearcher managementObjectSearcher10 = new ManagementObjectSearcher("Select * From Win32_processor");
															ManagementObjectCollection managementObjectCollection10 = managementObjectSearcher10.Get();
															string str10 = "";
															foreach (ManagementBaseObject managementBaseObject10 in managementObjectCollection10)
															{
																ManagementObject managementObject10 = (ManagementObject)managementBaseObject10;
																str10 = managementObject10["ProcessorID"].ToString();
															}
															Task<string> stringAsync10 = Form1.client.GetStringAsync("http://bloxtopia.xyz/api/register_hwid?hwid=" + str10);
															HttpWebRequest httpWebRequest10 = (HttpWebRequest)WebRequest.Create("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + str10);
															HttpWebResponse httpWebResponse10 = (HttpWebResponse)httpWebRequest10.GetResponse();
															string text24 = new StreamReader(httpWebResponse10.GetResponseStream()).ReadToEnd();
															bool flag81 = text24.ToString() != "false";
															if (flag81)
															{
																bool flag82 = text24.ToString() == "err";
																if (flag82)
																{
																	MessageBox.Show("An error has occurred.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																	base.Close();
																}
																else
																{
																	MessageBox.Show("Access Denied.", "Bloxtopia Launcher", MessageBoxButtons.OK, MessageBoxIcon.Hand);
																	base.Close();
																}
															}
															ProcessStartInfo[] array9 = new ProcessStartInfo[]
															{
																new ProcessStartInfo("C:\\Bloxtopia\\" + text3 + "\\Bloxtopia.exe", "-script \"dofile('http://bloxtopia.xyz/jscriptnew.php?t=" + text4 + "')\""),
																new ProcessStartInfo("C:\\Bloxtopia\\BAC.exe", text4)
															};
															MessageBox.Show("wait", "Could not load AE", MessageBoxButtons.OK, MessageBoxIcon.Hand);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06000002 RID: 2 RVA: 0x000039A4 File Offset: 0x00001BA4
		public async Task<string> IsHWIDBanned(string hwid)
		{
			string text = await Form1.client.GetStringAsync("http://bloxtopia.xyz/api/hwid_lookup?hwid=" + hwid);
			string beaned = text;
			text = null;
			return beaned;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x000039F4 File Offset: 0x00001BF4
		public Process[] StartProcesses(ProcessStartInfo[] infos, bool waitForExit)
		{
			ArrayList arrayList = new ArrayList();
			foreach (ProcessStartInfo startInfo in infos)
			{
				Process process = Process.Start(startInfo);
				if (waitForExit)
				{
					process.WaitForExit();
				}
				arrayList.Add(process);
			}
			return (Process[])arrayList.ToArray(typeof(Process));
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00003A5C File Offset: 0x00001C5C
		public void DownloadAndInstall(string Version)
		{
			Directory.CreateDirectory("C:\\Bloxtopia");
			using (WebClient webClient = new WebClient())
			{
				webClient.DownloadProgressChanged += this.wc_DownloadProgressChanged;
				webClient.DownloadFileAsync(new Uri("http://bloxtopia.xyz/clients/" + Version + ".zip"), "C:/Bloxtopia/" + Version + ".zip");
				while (webClient.IsBusy)
				{
					Application.DoEvents();
				}
				string sourceArchiveFileName = "C:\\Bloxtopia\\" + Version + ".zip";
				string text = "C:\\Bloxtopia\\" + Version;
				bool flag = Directory.Exists(text);
				if (flag)
				{
					this.DeleteDirectory(text);
				}
				ZipFile.ExtractToDirectory(sourceArchiveFileName, text);
				webClient.DownloadFileAsync(new Uri("http://bloxtopia.xyz/clients/btversion_" + Version), "C:/Bloxtopia/" + Version + "/btversion");
				while (webClient.IsBusy)
				{
					Application.DoEvents();
				}
				webClient.DownloadFileAsync(new Uri("http://bloxtopia.xyz/clients/BAC.exe"), "C:/Bloxtopia/BAC.exe");
				while (webClient.IsBusy)
				{
					Application.DoEvents();
				}
				webClient.DownloadFileAsync(new Uri("http://bloxtopia.xyz/clients/btreg.reg"), "C:\\Bloxtopia\\btreg.reg");
				while (webClient.IsBusy)
				{
					Application.DoEvents();
				}
				bool flag2 = File.Exists("C:/Bloxtopia/BloxtopiaLauncher.exe");
				if (flag2)
				{
					File.Move("C:/Bloxtopia/BloxtopiaLauncher.exe", "C:/Bloxtopia/BloxtopiaLauncher.exe.old");
				}
				webClient.DownloadFileAsync(new Uri("http://bloxtopia.xyz/clients/BloxtopiaUpdater.exe"), "C:/Bloxtopia/BloxtopiaLauncher.exe");
				Process process = Process.Start("regedit.exe", "/s C:\\Bloxtopia\\btreg.reg");
				process.WaitForExit();
				bool flag3 = File.Exists("C:/Bloxtopia/2007.zip");
				if (flag3)
				{
					File.Delete("C:/Bloxtopia/2007.zip");
				}
				bool flag4 = File.Exists("C:/Bloxtopia/2008.zip");
				if (flag4)
				{
					File.Delete("C:/Bloxtopia/2008.zip");
				}
				bool flag5 = File.Exists("C:/Bloxtopia/2009.zip");
				if (flag5)
				{
					File.Delete("C:/Bloxtopia/2009.zip");
				}
				bool flag6 = File.Exists("C:/Bloxtopia/2010.zip");
				if (flag6)
				{
					File.Delete("C:/Bloxtopia/2010.zip");
				}
				bool flag7 = File.Exists("C:/Bloxtopia/btreg.reg");
				if (flag7)
				{
					File.Delete("C:/Bloxtopia/btreg.reg");
				}
				MessageBox.Show("Bloxtopia has been installed successfully. You can now join games.", "Bloxtopia Updater");
				base.Close();
			}
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00003CC4 File Offset: 0x00001EC4
		private void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			this.progressBar.Value = e.ProgressPercentage;
			bool flag = e.ProgressPercentage == 100;
			if (flag)
			{
				this.canUnzip = true;
			}
			else
			{
				this.canUnzip = false;
			}
		}

		// Token: 0x06000006 RID: 6 RVA: 0x00003D06 File Offset: 0x00001F06
		private void progressBar_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000007 RID: 7 RVA: 0x00003D0C File Offset: 0x00001F0C
		public void DeleteDirectory(string targetDir)
		{
			File.SetAttributes(targetDir, FileAttributes.Normal);
			string[] files = Directory.GetFiles(targetDir);
			string[] directories = Directory.GetDirectories(targetDir);
			foreach (string path in files)
			{
				File.SetAttributes(path, FileAttributes.Normal);
				File.Delete(path);
			}
			foreach (string targetDir2 in directories)
			{
				this.DeleteDirectory(targetDir2);
			}
			Directory.Delete(targetDir, false);
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00003D06 File Offset: 0x00001F06
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00003D06 File Offset: 0x00001F06
		private void label1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x04000001 RID: 1
		public bool canUnzip = false;

		// Token: 0x04000002 RID: 2
		private static readonly HttpClient client = new HttpClient();
	}
}
