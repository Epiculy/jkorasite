﻿namespace BloxtopiaUpdater
{
	// Token: 0x02000002 RID: 2
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600000A RID: 10 RVA: 0x00003D94 File Offset: 0x00001F94
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.components != null;
			if (flag)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600000B RID: 11 RVA: 0x00003DCC File Offset: 0x00001FCC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::BloxtopiaUpdater.Form1));
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.progressBar = new global::System.Windows.Forms.ProgressBar();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.pictureBox1.BackgroundImage = global::BloxtopiaUpdater.Properties.Resources.BloxtopiaSquare;
			this.pictureBox1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox1.Image = global::BloxtopiaUpdater.Properties.Resources.BloxtopiaSquare;
			this.pictureBox1.InitialImage = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.InitialImage");
			this.pictureBox1.Location = new global::System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(80, 80);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 16f);
			this.label1.Location = new global::System.Drawing.Point(98, 12);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(185, 26);
			this.label1.TabIndex = 1;
			this.label1.Text = "Bloxtopia Updater";
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.progressBar.Location = new global::System.Drawing.Point(103, 61);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new global::System.Drawing.Size(306, 23);
			this.progressBar.TabIndex = 2;
			this.progressBar.Click += new global::System.EventHandler(this.progressBar_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(421, 108);
			base.Controls.Add(this.progressBar);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.pictureBox1);
			this.Cursor = global::System.Windows.Forms.Cursors.AppStarting;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Form1";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Bloxtopia Updater";
			base.Load += new global::System.EventHandler(this.Form1_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000003 RID: 3
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000004 RID: 4
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000005 RID: 5
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000006 RID: 6
		private global::System.Windows.Forms.ProgressBar progressBar;
	}
}
