﻿using System;
using System.IO;

namespace BloxtopiaUninstaller
{
	// Token: 0x02000002 RID: 2
	internal class Program
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		private static void Main(string[] args)
		{
			Program.DeleteRecursively("C:\\Bloxtopia");
			Console.WriteLine("Bloxtopia has been uninstalled. Press any key to continue.");
			Console.ReadKey();
		}

		// Token: 0x06000002 RID: 2 RVA: 0x0000206C File Offset: 0x0000026C
		public static void DeleteRecursively(string path)
		{
			if (Directory.Exists(path))
			{
				DirectoryInfo directoryInfo = new DirectoryInfo(path);
				foreach (FileInfo fileInfo in directoryInfo.GetFiles())
				{
					Console.WriteLine("Deleting " + fileInfo.FullName);
					try
					{
						fileInfo.Delete();
					}
					catch (Exception ex)
					{
						Console.WriteLine(ex.Message);
					}
					Console.WriteLine("Done!");
				}
				foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
				{
					Program.DeleteRecursively(directoryInfo2.FullName);
					Console.WriteLine("Deleting " + directoryInfo2.FullName);
					try
					{
						directoryInfo2.Delete(false);
					}
					catch (Exception ex2)
					{
						Console.WriteLine(ex2.Message);
					}
					Console.WriteLine("Done!");
				}
				Console.WriteLine("Deleting " + directoryInfo.FullName);
				try
				{
					directoryInfo.Delete(false);
				}
				catch (Exception ex3)
				{
					Console.WriteLine(ex3.Message);
				}
				Console.WriteLine("Done!");
			}
		}
	}
}
