﻿using System;
using System.Linq;
using System.ComponentModel;
using System.Management;
using System.Timers;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Stupidsploit
{
    static class Program
    {
        static Timer ProcessTimer = new Timer();
        static Timer ReplacementTimer = new Timer();
        static string Version = "1.2";
        static string Arguments;
        static string Victim;
        static string Replacement;

        static void Main(string[] args)
        {
            Console.Title = "Stupidsploit";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("================================================================================");
            Console.WriteLine("==                         STUPIDSPLOIT V{0} BY CARROT                        ==", Version);
            Console.WriteLine("==                     PRESS ANY KEY TO STOP STUPIDSPLOIT                     ==");
            Console.WriteLine("================================================================================");
            Console.WriteLine(String.Empty);
            Console.ResetColor();
            if (args.Count() == 2)
            {
                Victim = args[0];
                Replacement = args[1];
            }
            else
            {
                Console.WriteLine("Arguments not found. Run this as 'Stupidsploit.exe <processToKill> <replacement>' in the command line.");
                Console.ReadKey();
                Environment.Exit(0);
            }
            Console.WriteLine("Waiting for '{0}'...", Victim);
            ProcessTimer.Elapsed += new ElapsedEventHandler(ProcessTimerElapsed);
            ProcessTimer.Interval = 2500;
            ProcessTimer.Enabled = true;
            Console.ReadKey();
            Environment.Exit(0);
        }

        static void ProcessTimerElapsed(object source, ElapsedEventArgs e)
        {
            Process[] processes = Process.GetProcesses();

            foreach (Process process in processes)
            {
                if (process.MainWindowHandle != IntPtr.Zero && process.ProcessName != String.Empty)
                {
                    if (process.ProcessName.ToLower().Contains(Victim.ToLower().Replace(".exe", String.Empty)))
                    {
                        ProcessTimer.Stop();
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Found process!");
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("Getting ARGs...");
                        try
                        {
                            Arguments = process.GetCommandLine();
                        }
                        catch (Win32Exception ex) when ((uint)ex.ErrorCode == 0x80004005)
                        {
                            Console.ResetColor();
                            Console.WriteLine("Stupidsploit does not have access to the process. Run Stupidsploit as an administrator and try again.");
                            Console.ReadKey();
                            Environment.Exit(0);
                        }
                        catch (InvalidOperationException)
                        {
                            Console.ResetColor();
                            Console.WriteLine("The process killed itself before Stupidsploit could do anything.");
                            Console.ReadKey();
                            Environment.Exit(0);
                        }
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("Killing '{0}'...", Victim);
                        process.Kill();
                        string[] SplitArguments = Regex.Split(Arguments, @"(?<=[ ])");
                        SplitArguments = SplitArguments.Skip(1).ToArray();
                        string ProcessArguments = String.Join("", SplitArguments).Trim();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Starting new client ({0})...", Replacement);
                        Process NewProcess = new Process();
                        NewProcess.StartInfo.UseShellExecute = true;
                        NewProcess.StartInfo.FileName = Replacement;
                        NewProcess.StartInfo.Arguments = ProcessArguments;
                        NewProcess.Start();
                        ReplacementTimer.Elapsed += new ElapsedEventHandler(ReplacementTimerElapsed);
                        ReplacementTimer.Interval = 2500;
                        ReplacementTimer.Enabled = true;
                    }
                }
            }
        }

        static void ReplacementTimerElapsed(object source, ElapsedEventArgs e)
        {
            Process[] processes = Process.GetProcessesByName(Replacement.Split('\\').Last().Replace(".exe", String.Empty));
            foreach (Process process in processes)
            {
                if (process.MainWindowHandle != IntPtr.Zero)
                {
                    ReplacementTimer.Stop();
                    Console.ResetColor();
                    Console.WriteLine("Stupidsploit is finished!");
                }
            }
        }

        static string GetCommandLine(this Process process)
        {
            using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT CommandLine FROM Win32_Process WHERE ProcessId = " + process.Id))
            using (ManagementObjectCollection objects = searcher.Get())
            {
                return objects.Cast<ManagementBaseObject>().SingleOrDefault()?["CommandLine"]?.ToString();
            }
        }
    }
}
