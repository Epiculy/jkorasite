﻿using System;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Threading;

namespace BloxtopiaKiller
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter GameID here: ");
            string Line = Console.ReadLine();
            int Id;
            bool Parse = Int32.TryParse(Line, out Id);
            if (Parse)
            {

                Console.WriteLine("Getting data for GameID: " + Id);
                string Session = System.IO.File.ReadAllText(@"C:\Bloxtopia\BloxtopiaKiller\token.txt");
                Console.WriteLine("Getting game token");
                string[] TokenYear = Bloxtopia.GetGameToken(Id, Session).GetAwaiter().GetResult();
                Console.WriteLine("Getting join script");
                string JoinScript = Bloxtopia.GetJoinScript(TokenYear[0], Session).GetAwaiter().GetResult();
                string[] IpPort = Bloxtopia.GetIpPort(JoinScript);
                Console.WriteLine("Year: " + TokenYear[1] + ", Ip: " + IpPort[0] + ", Port: " + IpPort[1]);
                string PlayScript = System.IO.File.ReadAllText(@"C:\Bloxtopia\BloxtopiaKiller\join.lua").Replace("{{ip}}", IpPort[0]).Replace("{{port}}", IpPort[1]);
                string Payload = System.IO.File.ReadAllText(@"C:\Bloxtopia\BloxtopiaKiller\payload.lua");
                PlayScript = PlayScript.Replace("{{payload}}", Payload).Replace("\"", "\\\"");
                Process Client = new Process();
                Client.StartInfo.UseShellExecute = false;
                Client.StartInfo.Arguments = "-script \"" + PlayScript + "\"";
                Client.StartInfo.FileName = @"C:\Bloxtopia\" + TokenYear[1] + @"\Bloxtopia.exe";
                Client.StartInfo.CreateNoWindow = true;
                //Console.WriteLine("Waiting some time before starting client");
                //Thread.Sleep(5000);
                Client.Start();
                Console.WriteLine("Started client");
                Console.WriteLine("Finished");
                Main(new string[0]);
            }
            else
            {
                Console.WriteLine("Invalid integer");
                Main(new string[0]);
            }

        }
    }
    class Bloxtopia
    {
        public static int GetYear(string token)
        {
            Console.WriteLine(token.Substring(token.Length - 5, 4));
            return Int32.Parse(token.Substring(token.Length - 5, 4));
        }
        public static async Task<string[]> GetGameToken(int id, string session)
        {
            var baseAddress = new Uri("http://bloxtopia.xyz");
            CookieContainer cookieContainer = new CookieContainer();
            using (HttpClientHandler handler = new HttpClientHandler() { AllowAutoRedirect = false, CookieContainer = cookieContainer })
            using (HttpClient client = new HttpClient(handler) { BaseAddress = baseAddress })
            {
                cookieContainer.Add(baseAddress, new Cookie("PHPSESSID", session));
                client.DefaultRequestHeaders.Connection.Add("Keep-Alive");
                HttpResponseMessage response = await client.GetAsync("/2007/Join?id=" + id.ToString()).ConfigureAwait(continueOnCapturedContext: false);
                if ((int)response.StatusCode == 200)
                {
                    Console.WriteLine("Server is not up yet, retrying in 2 seconds");
                    Thread.Sleep(2000);
                    return Bloxtopia.GetGameToken(id, session).GetAwaiter().GetResult();
                }
                else
                {
                    string location = response.Headers.Location.ToString();
                    return new string[] { location.Substring(12, location.Length - 17).ToString(), location.Substring(location.Length - 5, 4).ToString() };
                }

            }
        }
        public static async Task<string> GetJoinScript(string token, string session)
        {
            var baseAddress = new Uri("http://bloxtopia.xyz");
            CookieContainer cookieContainer = new CookieContainer();
            using (HttpClientHandler handler = new HttpClientHandler() { AllowAutoRedirect = false, CookieContainer = cookieContainer })
            using (HttpClient client = new HttpClient(handler) { BaseAddress = baseAddress })
            {
                cookieContainer.Add(baseAddress, new Cookie("PHPSESSID", session));
                client.DefaultRequestHeaders.Connection.Add("Keep-Alive");
                HttpResponseMessage response = await client.GetAsync("/jscriptnew.php?t=" + token).ConfigureAwait(continueOnCapturedContext: false);
                return await response.Content.ReadAsStringAsync();
            }
        }
        public static string[] GetIpPort(string script)
        {
            string Ip = script.Substring(Regex.Match(script, @"client:Connect\(").Index + 16);
            string IpAfter = Ip.Substring(Regex.Match(Ip, "\\\", ").Index + 3);
            Ip = Ip.Substring(0, Regex.Match(Ip, "\\\", ").Index);
            string Port = IpAfter.Substring(0, Regex.Match(IpAfter, ",").Index);
            return new string[] { Ip, Port };
        }
    }
}
